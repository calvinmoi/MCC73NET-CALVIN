namespace API.ViewModels;

public class MEducationVM
{
  public int Id { get; set; }

  public string Degree { get; set; }

  public string GPA { get; set; }

  public string UniversityName { get; set; }

}