using Microsoft.EntityFrameworkCore;
using API.Contexts;
using API.Models;
using API.Repository.Interface;
using API.ViewModels;

namespace API.Repository.Data;

public class AccountRepositories : IRepository<Account, String>
{
  private MyContext _context;
  private DbSet<Account> _accounts;
  private readonly DbSet<Employee> _employees;
  private readonly DbSet<RegisterVM> _registervm;
  public AccountRepositories(MyContext context)
  {
    _context = context;
    _accounts = context.Set<Account>();
    _employees = context.Set<Employee>();
  }

  public int Delete(string id)
  {
    var data = _accounts.Find(id);
    if (data == null)
    {
      return 0;
    }

    _accounts.Remove(data);
    var result = _context.SaveChanges();
    return result;
  }


  public IEnumerable<Account> Get()
  {

    return _accounts.ToList();
  }

  public Account Get(string id)
  {
    return _accounts.Find(id);
  }

  public int Insert(Account entity)
  {
    _accounts.Add(entity);
    var result = _context.SaveChanges();
    return result;
  }

  public int Update(Account entity)
  {
    _accounts.Entry(entity).State = EntityState.Modified;
    var result = _context.SaveChanges();
    return result;
  }

  public IEnumerable<RegisterVM> MasterRegister()
  {
    var result = _accounts.Join(_employees, a => a.NIK, e => e.NIK, (a, e) => new RegisterVM
    {
      NIK = a.NIK,
      FullName = e.FirstName + " " + e.LastName,
      Phone = e.Phone,
      Gender = (ViewModels.Gender)e.Gender,
      Email = e.Email,
      Password = a.Password
    });

    return result;
  }

  public int Register(RegisterVM Register)
  {
    Account account = new Account()
    {
      NIK = Register.NIK,
      Password = Register.Password,
    };

    Employee employee = new Employee()
    {
      NIK = Register.NIK,
      FirstName = Register.FirstName,
      LastName = Register.LastName,
      Phone = Register.Phone,
      Gender = (Models.Gender)Register.Gender,
      BirthDate = Register.BirthDate,
      Salary = Register.Salary,
      Email = Register.Email,
    };

    _accounts.Add(account);
    _employees.Add(employee);

    var result = _context.SaveChanges();

    return result;
  }

  public string Login(LoginVM login)
  {
    string result = string.Empty;
    try
    {
      var log = _accounts.Join(_employees, a => a.NIK, e => e.NIK, (a, e) => new LoginVM
      {
        Email = e.Email,
        Password = a.Password
      }).Where(c => c.Email == login.Email).FirstOrDefault();
      if (result != null)
      {
        if (log.Password == login.Password)
        {
          result = "Login Success";
        }
        else if (log.Password != login.Password)
        {
          result = "Wrong Password";
        }
      }
    }
    catch
    {
      result = "Wrong Email / Password";
    }
    return result;
  }
}